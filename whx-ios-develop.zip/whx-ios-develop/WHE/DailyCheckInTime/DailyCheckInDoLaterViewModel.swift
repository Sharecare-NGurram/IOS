//
//  DailyCheckInDoLaterViewModel.swift
//  WHE
//
//  Created by Venkateswarlu Samudrala on 14/04/23.
//

import UIKit

class DailyCheckInDoLaterViewModel {
  
  let headerLineHeight = 1.1
  let descriptionLineHeight = 1.32
  let rewardsHeaderHeight = 1.05
  let rewardsDescriptionHeight = 1.24
  let starImg = "star"
  let bgOverlay = "BGOverlay"
}
