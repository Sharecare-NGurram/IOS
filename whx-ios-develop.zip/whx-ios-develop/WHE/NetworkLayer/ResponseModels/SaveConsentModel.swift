//
//  SaveConsentModel.swift
//  WHE
//
//  Created by Pratima Pundalik on 13/03/23.
//

import Foundation
struct SaveConsentModel {
    var addConsents: [String : String] = [:]
    var isConsentSaved: String?
    var saveConsentMessage: String?
}
