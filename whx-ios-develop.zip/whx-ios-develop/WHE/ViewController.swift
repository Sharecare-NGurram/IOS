//
//  ViewController.swift
//  WHE
//
//  Created by Srikanth Suryawanshi on 07/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
