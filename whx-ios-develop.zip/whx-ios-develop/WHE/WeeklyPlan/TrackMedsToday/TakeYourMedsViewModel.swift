//
//  TakeYourMedsViewModel.swift
//  WHE
//
//  Created by Venkateswarlu Samudrala on 14/04/23.
//

import UIKit

class TakeYourMedsViewModel {

  let noneButtonTag = 1
  let someButtonTag = 2
  let allButtonTag = 3
  let lineHeight = 1.1
  let yourMedsTodayBGImg = "YourMedsToday"
  let bgOverlay = "BGOverlay"
}
