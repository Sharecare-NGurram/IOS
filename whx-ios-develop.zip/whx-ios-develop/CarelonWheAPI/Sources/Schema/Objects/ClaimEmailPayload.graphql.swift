// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public extension Objects {
  /// The values necessary to update an email for a member securely
  static let ClaimEmailPayload = Object(
    typename: "ClaimEmailPayload",
    implementedInterfaces: []
  )
}