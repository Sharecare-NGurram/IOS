// @generated
// This file was automatically generated and should not be edited.

import ApolloAPI

public enum Query_getContentV3_items_type: String, EnumType {
  case privacy = "PRIVACY"
  case terms = "TERMS"
  case createLho = "CREATE_LHO"
  case linkLho = "LINK_LHO"
  case createSsoFromSydney = "CREATE_SSO_FROM_SYDNEY"
  case linkSsoFromSydney = "LINK_SSO_FROM_SYDNEY"
  case location = "LOCATION"
  case hipaa = "HIPAA"
  case dataSharing = "DATA_SHARING"
  case lhoPrivacy = "LHO_PRIVACY"
  case mobileText = "MOBILE_TEXT"
  case memberCareSupport = "MEMBER_CARE_SUPPORT"
  case careSupport = "CARE_SUPPORT"
  case earlyAccess = "EARLY_ACCESS"
}
